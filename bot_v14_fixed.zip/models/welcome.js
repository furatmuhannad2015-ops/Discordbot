// بديل MongoDB: نفس واجهة الموديل القديم (findOne / create / findOneAndDelete / save)
// لكن التخزين في pro.db (ملف json محلي) بدل mongoose.
const db = require("pro.db");

const defaults = {
  wsize: 500, hsize: 300,
  xavatar: 200, sxavatar: 100, yavatar: 30, syavatar: 100,
  xname: 200, yname: 150, sname: 25,
  ncolor: "#ffffff",
  message: "null", welchat: "null", pic: "null",
  welcome: false,
};

const key = (id) => `welcomer_${id}`;

function wrap(doc) {
  Object.defineProperty(doc, "save", {
    enumerable: false,
    value: async function () {
      const plain = { ...this };
      await db.set(key(this.id), plain);
      return this;
    },
  });
  return doc;
}

module.exports = {
  async findOne({ id }) {
    const saved = db.get(key(id));
    return saved ? wrap({ ...defaults, ...saved }) : null;
  },
  async create({ id, ...rest }) {
    const doc = wrap({ id, ...defaults, ...rest });
    await db.set(key(id), { ...doc });
    return doc;
  },
  async findOneAndDelete({ id }) {
    const old = db.get(key(id));
    await db.delete(key(id));
    return old || null;
  },
};
