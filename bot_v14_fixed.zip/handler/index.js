const glob = require("glob");
const { promisify } = require("util");
const { ApplicationCommandType } = require("discord.js");
const fs = require("fs");
const globPromise = promisify(glob);

module.exports = async (client) => {
  // ---- أوامر البريفكس ----
  const commandFiles = await globPromise(`${process.cwd()}/Commands/**/*.js`);
  commandFiles.forEach((value) => {
    try {
      const file = require(value);
      const splitted = value.split("/");
      const directory = splitted[splitted.length - 2];
      if (file.name) {
        client.commands.set(file.name, { directory, ...file });
      }
    } catch (err) {
      console.error(`❌ فشل تحميل الأمر ${value}:`, err.message);
    }
  });

  // ---- الأحداث ----
  const eventFiles = await globPromise(`${process.cwd()}/events/*.js`);
  eventFiles.forEach((value) => {
    try { require(value); } catch (err) { console.error(`❌ فشل تحميل الحدث ${value}:`, err.message); }
  });

  // ---- السلاش كوماند (مجلد SlashCommands اختياري) ----
  const slashCommands = await globPromise(`${process.cwd()}/SlashCommands/**/*.js`);
  const arrayOfslashCommands = [];
  slashCommands.forEach((value) => {
    const file = require(value);
    if (!file?.name) return;
    client.slashCommands.set(file.name, file);
    if ([ApplicationCommandType.Message, ApplicationCommandType.User, "MESSAGE", "USER"].includes(file.type)) {
      delete file.description;
    }
    arrayOfslashCommands.push(file);
  });
  client.on("ready", async () => {
    client.guilds.cache.forEach(async (guild) => {
      await guild.commands.set(arrayOfslashCommands).catch(() => {});
    });
  });

  // ---- ملفات السيرفر الإضافية (Extras/Guild) ----
  fs.readdirSync(`${__dirname}/../Extras/Guild/`)
    .filter((f) => f.endsWith(".js"))
    .forEach((f) => {
      try { require(`../Extras/Guild/${f}`); } catch (err) { console.error(`❌ فشل تحميل Extras/Guild/${f}:`, err); }
    });
};
