// طبقة توافق: تستخدم @napi-rs/canvas (جاهزة بدون بناء/سكربتات تثبيت)
// وتعطي نفس واجهة مكتبة canvas القديمة: createCanvas / loadImage / registerFont
const path = require("path");
const napi = require("@napi-rs/canvas");

function createCanvas(width, height, type) {
  const c = napi.createCanvas(width, height, type);
  const orig = c.toBuffer.bind(c);
  // canvas القديمة تعطي PNG إذا ما حددت النوع
  c.toBuffer = (mime = "image/png", ...rest) => orig(mime, ...rest);
  return c;
}

function registerFont(file, opts = {}) {
  try {
    napi.GlobalFonts.registerFromPath(path.resolve(file), opts.family);
  } catch (err) {
    console.error("⚠️ تعذر تحميل الخط:", file, err.message);
  }
}

module.exports = { ...napi, createCanvas, registerFont };
