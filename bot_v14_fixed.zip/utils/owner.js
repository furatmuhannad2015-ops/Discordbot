// يرجع true إذا كان صاحب الرسالة أونر (آيدي في owners)
// أو عنده رتبة من ownerRoles في config.json
module.exports = function checkOwner(source) {
  const config = require(`${process.cwd()}/config`);
  const id = source?.author?.id ?? source?.user?.id;
  if ((config.owners || []).includes(id)) return true;
  const roles = config.ownerRoles || [];
  if (!roles.length) return false;
  return !!source?.member?.roles?.cache?.some((r) => roles.includes(r.id));
};
