// بديل لمكتبة discord-inviter (غير متوافقة مع discord.js v14).
// يتتبّع الدعوات عبر مقارنة عدد استخدامات كل دعوة قبل/بعد دخول العضو.
const { EventEmitter } = require("events");
const db = require("pro.db");

const trackers = new WeakMap();
const countKey = (guildId, userId) => `invcount_${guildId}_${userId}`;

class inviteTracker extends EventEmitter {
  constructor(client) {
    if (trackers.has(client)) return trackers.get(client); // نسخة واحدة لكل بوت
    super();
    trackers.set(client, this);
    this.client = client;
    this.cache = new Map(); // guildId -> Map(code -> uses)

    const snapshot = async (guild) => {
      try {
        const invites = await guild.invites.fetch();
        this.cache.set(guild.id, new Map(invites.map((i) => [i.code, i.uses ?? 0])));
      } catch (e) {
        this.emit("error", guild, e);
      }
    };

    client.on("ready", () => client.guilds.cache.forEach(snapshot));
    client.on("guildCreate", snapshot);
    client.on("guildDelete", (g) => this.cache.delete(g.id));
    client.on("inviteCreate", (i) => {
      if (!i.guild) return;
      if (!this.cache.has(i.guild.id)) this.cache.set(i.guild.id, new Map());
      this.cache.get(i.guild.id).set(i.code, i.uses ?? 0);
    });
    client.on("inviteDelete", (i) => this.cache.get(i.guild?.id)?.delete(i.code));

    client.on("guildMemberAdd", async (member) => {
      const old = this.cache.get(member.guild.id) || new Map();
      let invites;
      try {
        invites = await member.guild.invites.fetch();
      } catch (e) {
        this.emit("guildMemberAdd", member, null, null, e);
        return;
      }
      const used = invites.find((i) => (i.uses ?? 0) > (old.get(i.code) ?? 0));
      this.cache.set(member.guild.id, new Map(invites.map((i) => [i.code, i.uses ?? 0])));

      const inviter = used?.inviter || null;
      let info = null;
      if (inviter) {
        const k = countKey(member.guild.id, inviter.id);
        const count = (Number(db.get(k)) || 0) + 1;
        await db.set(k, count);
        info = { code: used.code, count };
      }
      this.emit("guildMemberAdd", member, inviter, info, null);
    });
  }

  // عدد دعوات العضو: { count }
  static async getMemberInvites(member) {
    const m = member.member || member; // يقبل GuildMember أو User
    const guildId = m.guild?.id;
    const userId = m.id;
    return { count: guildId ? Number(db.get(countKey(guildId, userId))) || 0 : 0 };
  }
}

module.exports = { inviteTracker };
