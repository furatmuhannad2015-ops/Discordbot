const { ApplicationCommandOptionType, ActivityType } = require("discord.js");
const client = require("../index");
client.on("interactionCreate", async (interaction) => {
    if (interaction.isChatInputCommand()) {
        const cmd = client.slashCommands.get(interaction.commandName);
 if(!cmd)       return interaction.reply({
        content: `> **An Error Occured**`,
         ephemeral: true})
        const args = [];
        for (let option of interaction.options.data) {
            if (option.type === ApplicationCommandOptionType.Subcommand) {
                if (option.name) args.push(option.name);
                option.options?.forEach((x) => {
                    if (x.value) args.push(x.value);
                });
            } else if (option.value) args.push(option.value);
        }
        interaction.member = interaction.guild.members.cache.get(interaction.user.id);
        cmd.run(client, interaction, args);
    }
    if (interaction.isContextMenuCommand()) {
        const command = client.slashCommands.get(interaction.commandName);
        if (command) command.run(client, interaction);
    }
});

// ---- نفس السلوك القديم لكن بصيغة مقروءة (كان مشفّر) ----
client.once("ready", () => {
  console.log("Developer : MonsterTeam \nStore : discord.gg/MonsterTeam ");
});
client.setMaxListeners(999999);
client.on("ready", () => {
  client.user.setPresence({
    status: "dnd",
    activities: [
      {
        name: "MonsterTeam",
        type: ActivityType.Streaming,
        url: "https://www.twitch.tv/MonsterTeamOnTop",
      },
    ],
  });
});
