module.exports = {
    name: 'lock', // هنا اسم الامر
  aliases: ["قفل","ق"],
    run : (client, message, args) => {


              const Pro = require(`pro.db`)
        const db = Pro.get(`Allow - Command lock = [ ${message.guild.id} ]`)
const allowedRole = message.guild.roles.cache.get(db);
const isAuthorAllowed = message.member.roles.cache.has(allowedRole?.id);

if (!isAuthorAllowed && message.author.id !== db  && !message.member.permissions.has('ManageChannels')) {
    // إجراءات للتصرف عندما لا يتحقق الشرط
    return message.react('❌')
}


      
   // const permission = message.member.permissions.has("ManageChannels");
    const guilds = message.guild.members.me.permissions.has("ManageChannels");
    const a8rgs = message.content.split(' ')
    const channel = message.mentions.channels.first() || client.channels.cache.get(a8rgs[1]) || message.channel;

    if (!guilds) return message.reply({ content: `:rolling_eyes: **I couldn't edit the channel permissions. Please check my permissions and role position.**`, ephemeral: true }).catch((err) => {
      console.log(`i couldn't reply to the message: ` + err.message)
    })
    let everyone = message.guild.roles.cache.find(hyper => hyper.name === '@everyone');
    channel.permissionOverwrites.edit(everyone, {
      SendMessages: false,
      SEND_MESSAGES_IN_THREADS: false,
      CREATE_PUBLIC_THREADS: false,
      CREATE_PRIVATE_THREADS: false
    }).then(() => {
      message.react("✅").catch((err) => {
        console.log(`i couldn't reply to the message: ` + err.message)
      })
    })
 
 }   
}
