const { ChannelType } = require("discord.js");
const Discord = require(`discord.js`);
module.exports = {
    name: `slowmode`,
    run: async (client, message) => {
      


              const Pro = require(`pro.db`)
        const db = Pro.get(`Allow - Command slowmode = [ ${message.guild.id} ]`)
const allowedRole = message.guild.roles.cache.get(db);
const isAuthorAllowed = message.member.roles.cache.has(allowedRole?.id);

if (!isAuthorAllowed && message.author.id !== db  && !message.member.permissions.has('Administrator')) {
    // إجراءات للتصرف عندما لا يتحقق الشرط
    return message.react('❌');
}
      

 // if (!message.member.permissions.has('Administrator')) {
   // return message.react('❌');
 // }

  if (message.author.bot || message.channel.type === ChannelType.DM) {
    return;
  }

  const args = message.content.split(" ");
  if (isNaN(args[1])) {
    return message.react('🕐');
  }

  message.react('🕐');
  message.channel.setRateLimitPerUser(args[1]);

        
    }
}