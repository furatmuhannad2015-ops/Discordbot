const { EmbedBuilder } = require("discord.js");
const db = require(`pro.db`);

module.exports = {
  name: 'allbans',
  run: (client, message, args) => {
    const Pro = require(`pro.db`);
    const Data = db.get(`Allow - Command allbans = [ ${message.guild.id} ]`);
    const allowedRole = message.guild.roles.cache.get(Data);
    const isAuthorAllowed = message.member.roles.cache.has(allowedRole?.id);

    if (!isAuthorAllowed && message.author.id !== Data && !message.member.permissions.has('Administrator')) {
      return message.react('❌');
    }

    const Color = db.get(`Guild_Color = ${message.guild.id}`) || message.guild.members.me.displayHexColor || `#000000`;
    if (!Color) return;

    message.guild.bans.fetch()
      .then(bans => {
        let list = '';
        let count = 1;
        bans.forEach(ban => {
          const user = ban.user;
          const reason = ban.reason || '❌';
          list += ` \`${count}\` - <@${user.id}> - Reason : ${reason}\n`;
          count++;
        });

        if (list.length >= 1950) list = `${list.slice(0, 1948)}`;

        const embed = new EmbedBuilder()
          .setColor(`${Color || message.guild.members.me.displayHexColor || `#000000`}`)
          .setTitle(`قائمه الإعضاء المحظورة : \`${bans.size}\``)
          .setDescription(`**${list}**`)
          .setThumbnail(client.user.displayAvatarURL({}))
          .setFooter({ text: `${message.author.tag}`, iconURL: message.author.displayAvatarURL({}) });

        message.channel.send({ embeds: [embed] });
      })
      .catch(console.error);
  }
};
