const { ButtonStyle } = require("discord.js");
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, Client } = require("discord.js");

module.exports = {
  name: "autoreply",
  aliases: ["إضافة"],
  description: "A simple ping command.",
  category: "Informations",
  example: ["1"],
  run: async (Client, Message) => {
    if (!Message.member.permissions.has("Administrator")) return;

    const Embed = new EmbedBuilder()
     // .setDescription("لـ اضافه رد تلقائي\nأضغط عليـ الزر ومن ثم اضف الكلمه ومن ثم الرد")
      .setTimestamp()
      .setColor("2f3136")
      .setThumbnail(Client.user.displayAvatarURL({}));
    const Bu = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId("Auto_Reply").setStyle(ButtonStyle.Secondary).setLabel("Addreply ➕")
    );
    await Message.reply({ embeds: [Embed], components: [Bu] });
  },
};
