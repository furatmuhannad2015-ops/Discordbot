const checkOwner = require(`${process.cwd()}/utils/owner`);
const { ChannelType } = require("discord.js");
const { owners } = require(`${process.cwd()}/config`);

module.exports = {
  name: 'log-creat',
  run: async (client, message) => {
    if (!checkOwner(message)) return;

    let guild = message.guild;
    let channels = ["log-join-leave", "log-ban-unban", "log-kick", "log-messages", "log-pic", "log-roles", "log-links", "log-nickname", "log-channels", "log-vjoin-vexit", "log-move", "log-tmute-untmute", "log-bots", "log-prison-unprison"];
    let category = guild.channels.cache.find(channel => channel.name === "logs" && channel.type === ChannelType.GuildCategory);

    if (!category) {
      category = await guild.channels.create({ name: "logs", type: ChannelType.GuildCategory,
        permissionOverwrites: [
          { id: guild.roles.everyone, deny: ["SendMessages", "ViewChannel"] }
        ]
      });
    }

    for (let ch of channels) {
      let existingChannel = guild.channels.cache.find(channel => channel.name === ch && channel.type === ChannelType.GuildText && channel.parentId === category.id);
      if (!existingChannel) {
        await guild.channels.create({ name: ch, type: ChannelType.GuildText, parent: category });
      }
    }

    await message.react("✅");
  }
}
