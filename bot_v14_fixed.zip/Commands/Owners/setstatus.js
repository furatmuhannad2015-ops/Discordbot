const checkOwner = require(`${process.cwd()}/utils/owner`);
const { ActivityType, ButtonStyle } = require("discord.js");
const Discord = require('discord.js');
const { owners } = require(`${process.cwd()}/config`);
const db = require('pro.db');

module.exports = {
  name: 'setstatus',
  run: async (client, message) => {
    const Data = db.get(`Allow - Command setgame = [ ${message.guild.id} ]`);
    const allowedRole = message.guild.roles.cache.get(Data);
    const isAuthorAllowed = message.member.roles.cache.has(allowedRole?.id);
    const isOwner = checkOwner(message);
  
    if (!isAuthorAllowed && message.author.id !== Data && !isOwner) {
      return message.react('❌');
    }
      
    const args = message.content.split(' ').slice(1).join(' ');
    if (!args) return message.reply('**يرجى كتابة الحالة الجديدة.**');
  
    const row = new Discord.ActionRowBuilder()
      .addComponents(
        new Discord.ButtonBuilder()
          .setCustomId('playing')
          .setLabel('Playing')
          .setStyle(ButtonStyle.Primary),
        new Discord.ButtonBuilder()
          .setCustomId('listening')
          .setLabel('Listening')
          .setStyle(ButtonStyle.Primary),
        new Discord.ButtonBuilder()
          .setCustomId('streaming')
          .setLabel('Streaming')
          .setStyle(ButtonStyle.Primary),
        new Discord.ButtonBuilder()
          .setCustomId('watching')
          .setLabel('Watching')
          .setStyle(ButtonStyle.Primary),
        new Discord.ButtonBuilder()
          .setCustomId('cancel')
          .setLabel('Cancel')
          .setStyle(ButtonStyle.Danger)
      );
  
    message.reply({
      components: [row],
    });
  
    const filter = (interaction) => interaction.user.id === message.author.id;
    const collector = message.channel.createMessageComponentCollector({ filter, time: 90000 });
  
    collector.on('collect', async (interaction) => {
      if (interaction.customId === 'playing') {
        interaction.reply({
          content: 'تم تغيير الحالة إلى PLAYING',
          ephemeral: true, // Make the response hidden
        });
        await db.set(`status_${message.guild.id}`, { name: args, type: ActivityType.Playing });
        await client.user.setPresence({ status: 'idle', activities: [{ name: args, type: ActivityType.Playing }] });
      } else if (interaction.customId === 'listening') {
        interaction.reply({
          content: 'تم تغيير الحالة إلى LISTENING',
          ephemeral: true, // Make the response hidden
        });
        await db.set(`status_${message.guild.id}`, { name: args, type: ActivityType.Listening });
        await client.user.setPresence({ status: 'idle', activities: [{ name: args, type: ActivityType.Listening }] });
      } else if (interaction.customId === 'streaming') {
        interaction.reply({
          content: 'تم تغيير الحالة إلى STREAMING',
          ephemeral: true, // Make the response hidden
        });
        await db.set(`status_${message.guild.id}`, { name: args, type: ActivityType.Streaming, url: 'https://www.twitch.tv/7lm' });
        await client.user.setPresence({ status: 'idle', activities: [{ name: args, type: ActivityType.Streaming, url: 'https://www.twitch.tv/7lm' }] });
      } else if (interaction.customId === 'watching') {
        interaction.reply({
          content: 'تم تغيير الحالة إلى WATCHING',
          ephemeral: true, // Make the response hidden
        });
        await db.set(`status_${message.guild.id}`, { name: args, type: ActivityType.Watching });
        await client.user.setPresence({ status: 'idle', activities: [{ name: args, type: ActivityType.Watching }] });
      } else if (interaction.customId === 'cancel') {
        interaction.reply({
          content: 'تم الإلغاء',
          ephemeral: true, // Make the response hidden
        });
      }
    });
  }}
  