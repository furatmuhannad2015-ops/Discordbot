const getJimp = () => require('jimp'); // يتحمّل وقت الاستخدام فقط
const { AttachmentBuilder } = require('discord.js');
module.exports = {
    name: 'change', // هنا اسم الامر
    run: async (client, message, args) => {
       try {
          let imageUrl;
          if (message.attachments.size > 0) {
             imageUrl = message.attachments.first().url;
          } else {
             imageUrl = message.author.displayAvatarURL({ extension: 'png' })

          }
          if (!imageUrl) return;
          const image = await getJimp().read(imageUrl);
          image.greyscale();
          image.resize(800, getJimp().AUTO); // تغيير حجم الصورة إلى عرض 800 بكسل وارتفاع تلقائي
          const convertedImageBuffer = await image.getBufferAsync(getJimp().MIME_PNG);
          const Image = new AttachmentBuilder(convertedImageBuffer, { name: 'converted-image.png' });
          const loadingMessage = await message.channel.send("** برجاء الانتظار .. ⏰**");
          await message.reply({ files: [Image] });
          await loadingMessage.delete();
       } catch {
          return;
       }
    }
}
