const checkOwner = require(`${process.cwd()}/utils/owner`);
const {owners } = require(`${process.cwd()}/config`);
module.exports = {
    name: 'ping', // هنا اسم الامر
    run : (client, message, args) => {



              const Pro = require(`pro.db`)
        const db = Pro.get(`Allow - Command ping = [ ${message.guild.id} ]`)
const allowedRole = message.guild.roles.cache.get(db);
const isAuthorAllowed = message.member.roles.cache.has(allowedRole?.id);
const isOwner = checkOwner(message);

if (!isAuthorAllowed && message.author.id !== db && !isOwner) {
    // إجراءات للتصرف عندما لا يتحقق الشرط
    return message.react('❌');
}
      
    message.reply(`my ping is **${client.ws.ping}** 🎯`);
    }
}


