const { AttachmentBuilder } = require("discord.js");
const { createCanvas, loadImage } = require(`${process.cwd()}/utils/canvas`);

// يقص الصورة على شكل دائرة (PNG)
async function drawCircle({ image }) {
  const img = await loadImage(image);
  const size = Math.min(img.width, img.height);
  const canvas = createCanvas(size, size);
  const ctx = canvas.getContext("2d");
  ctx.beginPath();
  ctx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2);
  ctx.closePath();
  ctx.clip();
  ctx.drawImage(img, (img.width - size) / 2, (img.height - size) / 2, size, size, 0, 0, size, size);
  return new AttachmentBuilder(canvas.toBuffer(), { name: "circle.png" });
}

module.exports = {
  name: "circle",
  run: async (Client, message) => {
    if (!message.guild || message.author.bot) return;
    const args = message.content.split(/ +/);

    const user =
      message.mentions.members.first() ||
      (args[1] ? await Client.users.fetch(args[1]).catch(() => null) : null) ||
      message.member;
    const attach = message.attachments.first()?.proxyURL ?? null;

    await message.channel.sendTyping();
    let avatar;
    if (attach) avatar = attach;
    else if (args[1]?.startsWith("http")) avatar = args[1];
    else if (user) avatar = user.displayAvatarURL({ extension: "jpg", size: 2048 });

    try {
      const file = await drawCircle({ image: avatar });
      message.reply({ files: [file] });
    } catch (err) {
      return message.reply({ content: `> خطأ!, لم استطع التعرف على الصورة` });
    }
  },
};
